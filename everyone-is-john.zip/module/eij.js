Hooks.on('renderChatMessage', (message, html, data) => {
  if (message.flags['everyone-is-john']) {
    const template = 'systems/everyone-is-john/templates/chat/everyone-is-john.hbs';
    const content = {
      name: message.speaker.alias,
      description: message.content
    };
    renderTemplate(template, content).then(renderedContent => {
      html.find('.message-content').html(renderedContent);
    });
  }
});

Hooks.on('chatMessage', (chatLog, messageText, chatData) => {
  if (messageText.startsWith('/john ')) {
    const johnDescription = messageText.slice(6);
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker(),
      content: johnDescription,
      flags: {
        'everyone-is-john': true
      }
    });
    return false;
  }
});
